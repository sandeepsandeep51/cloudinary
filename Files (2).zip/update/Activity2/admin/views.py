from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def admin_dashboard(request):
    return render(request, 'admin_templates/dashboard.html')

@login_required
def admin_profile(request):
    return render(request, 'admin_templates/profile.html')

@login_required
def staff_management(request):
    return render(request, 'admin_templates/staff_management.html')

@login_required
def student_management(request):
    return render(request, 'admin_templates/student_management.html')

@login_required
def leave_management(request):
    return render(request, 'admin_templates/leave_management.html')

@login_required
def activity_management(request):
    return render(request, 'admin_templates/activity_management.html')

@login_required
def late_records(request):
    return render(request, 'admin_templates/late_records.html')

@login_required
def announcements(request):
    return render(request, 'admin_templates/announcements.html')

@login_required
def download_reports(request):
    return render(request, 'admin_templates/download_reports.html')

@login_required
def action_logs(request):
    return render(request, 'admin_templates/action_logs.html')

@login_required
def admin_announcements(request):
    return render(request, 'admin_templates/admin_announcements.html')