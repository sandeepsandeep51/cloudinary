from django.db import migrations

class Migration(migrations.Migration):

    dependencies = [
        ('student', '0001_initial'),
    ]

    operations = [
        migrations.DeleteModel(
            name='LeaveRequest',
        ),
    ]