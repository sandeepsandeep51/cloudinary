from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from admin_portal.models import StudentProfile, LeaveRequest, ActionLog
from staff.models import ShopTalkSession, ShopTalkSubmission
from admin_portal.models import LateRecord

@login_required
def student_dashboard(request):
    if request.user.role != 'student':
        return redirect('login')
    return render(request, 'student/dashboard.html')

@login_required
def student_profile(request):
    if request.user.role != 'student':
        return redirect('login')
    
    context = {
        'user': request.user,
        'student_profile': StudentProfile.objects.get(user=request.user),
        'created_by': request.user.created_by
    }
    return render(request, 'student/profile.html', context)

@login_required
def update_student_profile(request):
    if request.method == 'POST' and request.user.role == 'student':
        try:
            user = request.user
            student_profile = StudentProfile.objects.get(user=user)
            
            # Update allowed fields
            student_profile.student_name = request.POST.get('student_name')
            user.email = request.POST.get('email')
            user.phone = request.POST.get('phone')
            user.address = request.POST.get('address')
            
            user.save()
            student_profile.save()
            messages.success(request, 'Profile updated successfully')
        except Exception as e:
            messages.error(request, f'Error updating profile: {str(e)}')
    
    return redirect('student_profile')

@login_required
def student_leave(request):
    if request.user.role != 'student':
        return redirect('login')
    
    student_profile = request.user.studentprofile
    
    if request.method == 'POST':
        try:
            # Convert string dates to datetime objects
            from datetime import datetime
            
            # Create new leave request with datetime conversion
            leave_request = LeaveRequest.objects.create(
                student=student_profile,
                leave_type=request.POST['leave_type'],
                reason=request.POST['reason'],
                from_date=datetime.strptime(request.POST['from_date'], '%Y-%m-%d').date(),
                to_date=datetime.strptime(request.POST['to_date'], '%Y-%m-%d').date(),
                from_time=datetime.strptime(request.POST['from_time'], '%H:%M').time(),
                to_time=datetime.strptime(request.POST['to_time'], '%H:%M').time(),
                status='PENDING'
            )
            
            if 'document' in request.FILES:
                leave_request.document = request.FILES['document']
                leave_request.save()
            
            messages.success(request, 'Leave request submitted successfully')
            return redirect('student_leave')
            
        except Exception as e:
            print(f"Error creating leave request: {str(e)}")
            messages.error(request, f'Error submitting leave request: {str(e)}')
    
    leave_requests = LeaveRequest.objects.filter(student=student_profile).order_by('-created_at')
    
    context = {
        'student_details': {
            'name': student_profile.student_name,
            'token': f"TOK{student_profile.id:04d}",
            'semester': student_profile.semester
        },
        'leave_requests': leave_requests
    }
    
    return render(request, 'student/leave.html', context)

@login_required
def student_shoptalk(request):
    if request.user.role != 'student':
        return redirect('login')
    
    # Handle file upload
    if request.method == 'POST' and request.FILES.get('submission_file'):
        session_id = request.POST.get('session_id')
        file = request.FILES['submission_file']
        
        try:
            session = ShopTalkSession.objects.get(id=session_id)
            
            # Create submission with pending review status
            submission = ShopTalkSubmission.objects.create(
                session=session,
                student=request.user,
                submitted_file=file,
                status='submitted'  # This will show as "Pending Review"
            )
            messages.success(request, 'File uploaded successfully! Waiting for review.')
            return redirect('student_shoptalk')
        except Exception as e:
            messages.error(request, f'Error uploading file: {str(e)}')
    
    tab = request.GET.get('tab', 'all')
    sessions = ShopTalkSession.objects.filter(assigned_students=request.user)
    
    if tab == 'pending':
        sessions = sessions.filter(shoptalksubmission__status='submitted')
    elif tab == 'submitted':
        sessions = sessions.filter(shoptalksubmission__status='evaluated')
    elif tab == 'not_submitted':
        sessions = sessions.exclude(shoptalksubmission__isnull=False)
    
    sessions = sessions.prefetch_related('shoptalksubmission_set').order_by('-scheduled_date')
    
    context = {
        'sessions': sessions,
        'tab': tab,
        'pending_count': ShopTalkSubmission.objects.filter(
            student=request.user,
            status='submitted'
        ).count(),
        'submitted_count': ShopTalkSubmission.objects.filter(
            student=request.user,
            status='evaluated'
        ).count(),
        'not_submitted_count': ShopTalkSession.objects.filter(
            assigned_students=request.user
        ).exclude(
            shoptalksubmission__student=request.user
        ).count()
    }
    
    return render(request, 'student/shoptalk.html', context)

@login_required
def student_projects(request):
    if request.user.role != 'student':
        return redirect('login')
    return render(request, 'student/projects.html')

@login_required
def student_latecoming(request):
    if request.user.role != 'student':
        return redirect('login')
    
    try:
        student_profile = StudentProfile.objects.get(user=request.user)
        
        if request.method == 'POST':
            # Create late record
            late_record = LateRecord.objects.create(
                student=student_profile,
                date=request.POST.get('date'),
                time_arrived=request.POST.get('time_arrived'),
                reason=request.POST.get('reason')
            )
            
            messages.success(request, 'Late coming record submitted successfully')
            return redirect('student_latecoming')
        
        # Get student's late records
        late_records = LateRecord.objects.filter(
            student=student_profile
        ).order_by('-date', '-time_arrived')
        
        context = {
            'late_records': late_records
        }
        return render(request, 'student/latecoming.html', context)
        
    except StudentProfile.DoesNotExist:
        messages.error(request, 'Student profile not found')
        return redirect('student_dashboard')
    except Exception as e:
        messages.error(request, f'Error: {str(e)}')
        return redirect('student_dashboard')

@login_required
def activity_planner(request):
    return render(request, 'student/activity_planner.html')

@login_required
def activity_hours(request):
    return render(request, 'student/activity_hours.html')

@login_required
def feedback(request):
    return render(request, 'student/feedback.html')
