ROLE_PERMISSIONS = {
    'superadmin': [
        'manage_centers',
        'manage_courses',
        'manage_admins',
        'manage_roles',
        'view_reports',
        'view_logs',
    ],
    'admin': [
        'manage_center',
        'manage_courses',
        'view_reports',
    ],
    'staff': [
        'view_courses',
        'manage_students',
        'view_reports',
    ],
    'student': [
        'view_course_materials',
        'submit_assignments',
        'view_grades',
    ]
}

def has_permission(user, permission):
    if not user.is_authenticated:
        return False
    return permission in ROLE_PERMISSIONS.get(user.role, [])