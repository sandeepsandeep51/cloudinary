from functools import wraps
from django.core.exceptions import PermissionDenied
from .permissions import has_permission

def permission_required(permission):
    def decorator(view_func):
        @wraps(view_func)
        def wrapper(request, *args, **kwargs):
            if has_permission(request.user, permission):
                return view_func(request, *args, **kwargs)
            raise PermissionDenied
        return wrapper
    return decorator