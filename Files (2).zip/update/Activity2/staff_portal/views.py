@login_required
def student_management(request):
    if request.user.role != 'staff':
        return redirect('login')
    
    # Get students created by current staff member
    students = StudentProfile.objects.filter(
        created_by=request.user
    ).select_related('user')
    
    context = {
        'students': students
    }
    return render(request, 'staff_portal/student_management.html', context)

@login_required
def create_student(request):
    if request.method == 'POST':
        try:
            # Create user account
            user = User.objects.create_user(
                username=request.POST['username'],
                email=request.POST['email'],
                password=request.POST['password'],
                role='student',
                center=request.user.center,
                course=request.user.course
            )
            
            # Create student profile and explicitly set created_by
            StudentProfile.objects.create(
                user=user,
                student_name=request.POST['student_name'],
                roll_number=request.POST['roll_number'],
                semester=request.POST['semester'],
                section=request.POST['section'],
                created_by=request.user  # Make sure this is set correctly
            )
            
            # Debug print
            print(f"Student created by staff: {request.user.id}")
            
            messages.success(request, 'Student account created successfully')
        except Exception as e:
            messages.error(request, f'Error creating student account: {str(e)}')
        
        return redirect('student_management')