from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from admin_portal.models import StudentProfile, LeaveRequest, ActionLog
from .models import StaffProfile
from student.models import StudentProfile
from admin_portal.models import ActionLog  # Add this import
from django.utils import timezone

from django.contrib.auth import get_user_model
from admin_portal.models import StudentProfile
from staff.models import ShopTalkSession, ShopTalkSubmission
from django.http import JsonResponse
from admin_portal.models import Announcement  # Add this import

User = get_user_model()

@login_required
def staff_dashboard(request):
    if request.user.role != 'staff':
        return redirect('login')
        
    # Get actual count of students created by this staff
    total_students = StudentProfile.objects.filter(user__created_by=request.user).count()
    
    context = {
        'total_students': total_students,
        'pending_leaves': 7,
        'todays_activities': 3,
        'late_comers': 2
    }
    return render(request, 'staff/dashboard.html', context)

@login_required
def staff_profile(request):
    if request.user.role != 'staff':
        return redirect('login')
    
    context = {
        'staff_name': request.user.first_name + ' ' + request.user.last_name,
        'username': request.user.username,
        'email': request.user.email,
        'role': request.user.role,
        'center': request.user.center,  # From admin who created the account
        'course': request.user.course,  # From admin who created the account
        'phone': request.user.phone if hasattr(request.user, 'phone') else '',
        'address': request.user.address if hasattr(request.user, 'address') else ''
    }
    return render(request, 'staff/profile.html', context)

@login_required
def student_details(request):
    if request.user.role != 'staff':
        return redirect('login')
    
    # Get all students created by this staff member
    students = StudentProfile.objects.filter(
        user__created_by=request.user
    ).select_related('user')
    
    context = {
        'students': students,
        'total_students': students.count()
    }
    return render(request, 'staff/student_details.html', context)

@login_required
def create_student(request):
    if request.method == 'POST':
        try:
            # Check if username already exists
            if User.objects.filter(username=request.POST['username']).exists():
                messages.error(request, 'Username already exists. Please choose a different username.')
                return render(request, 'staff/create_student.html')

            # Create user account with staff's center and course
            student_user = User.objects.create_user(
                username=request.POST['username'],
                email=request.POST['email'],
                password=request.POST['password'],
                first_name=request.POST['student_name'],
                role='student',
                center=request.user.center,
                course=request.user.course,
                created_by=request.user
            )
            
            # Create student profile
            StudentProfile.objects.create(
                user=student_user,
                student_name=request.POST['student_name'],
                roll_number=request.POST['roll_number'],
                semester=request.POST['semester'],
                section=request.POST['section']
            )
            messages.success(request, 'Student account created successfully')
            return redirect('student_details')
        except Exception as e:
            messages.error(request, f'Error creating student account: {str(e)}')
            return render(request, 'staff/create_student.html')
    
    return render(request, 'staff/create_student.html')

@login_required
def edit_student(request, student_id):
    if request.user.role != 'staff':
        return redirect('login')
    
    try:    
        student = StudentProfile.objects.get(
            id=student_id,
            user__created_by=request.user  # Changed from created_by to user__created_by
        )
        
        if request.method == 'POST':
            student.student_name = request.POST['student_name']
            student.roll_number = request.POST['roll_number']
            student.user.email = request.POST['email']
            student.semester = request.POST['semester']
            student.section = request.POST['section']
            
            if request.POST.get('password'):
                student.user.set_password(request.POST['password'])
                
            student.user.save()
            student.save()
            messages.success(request, 'Student details updated successfully')
            return redirect('student_details')
            
        return render(request, 'staff/edit_student.html', {'student': student})
        
    except StudentProfile.DoesNotExist:
        messages.error(request, 'Student not found or you do not have permission to edit')
        return redirect('student_details')

@login_required
def delete_student(request, student_id):
    if request.user.role != 'staff':
        return redirect('login')
        
    try:
        # Get student profile created by current staff
        student = StudentProfile.objects.get(
            id=student_id,
            user__created_by=request.user
        )
        # Store user object before deleting profile
        user = student.user
        # Delete student profile first
        student.delete()
        # Then delete user account
        user.delete()
        messages.success(request, 'Student deleted successfully')
    except StudentProfile.DoesNotExist:
        messages.error(request, 'Student not found or you do not have permission to delete')
    except Exception as e:
        messages.error(request, f'Error deleting student: {str(e)}')
        
    return redirect('student_details')

@login_required
def leave_requests(request):
    if request.user.role != 'staff':
        return redirect('login')
    
    # Get students created by this staff member
    students = StudentProfile.objects.filter(user__created_by=request.user)
    
    # Get leave requests for these students only
    leave_requests = LeaveRequest.objects.filter(
        student__in=students
    ).select_related('student', 'student__user').order_by('-from_date')
    
    # Apply filters if any
    student_name = request.GET.get('student_name')
    status = request.GET.get('status')
    from_date = request.GET.get('from_date')
    to_date = request.GET.get('to_date')
    
    if student_name:
        leave_requests = leave_requests.filter(student__student_name__icontains=student_name)
    if status:
        leave_requests = leave_requests.filter(status=status)
    if from_date:
        leave_requests = leave_requests.filter(from_date__gte=from_date)
    if to_date:
        leave_requests = leave_requests.filter(to_date__lte=to_date)
    
    context = {
        'leave_requests': leave_requests,
        'total_requests': leave_requests.count(),
        'pending_requests': leave_requests.filter(status='PENDING').count(),
        'verified_requests': leave_requests.filter(status='VERIFIED').count(),
        'rejected_requests': leave_requests.filter(status='REJECTED').count()
    }
    
    return render(request, 'staff/leave_requests.html', context)

@login_required
def verify_leave(request, leave_id):
    if request.user.role != 'staff':
        return redirect('login')
        
    try:
        # Get leave request and verify it belongs to a student created by this staff
        leave_request = LeaveRequest.objects.get(
            id=leave_id,
            student__user__created_by=request.user
        )
        
        if request.method == 'POST':
            action = request.POST.get('action')
            
            if action == 'verify':
                leave_request.status = 'VERIFIED'
                leave_request.verified_by = request.user
                messages.success(request, 'Leave request verified successfully')
            elif action == 'reject':
                leave_request.status = 'REJECTED'
                leave_request.rejection_reason = "Rejected by staff"
                messages.success(request, 'Leave request rejected successfully')
            
            leave_request.save()
            
            # Log the action
            ActionLog.objects.create(
                user=request.user,
                action_type='UPDATE',
                action_description=f'Leave request {action}d for {leave_request.student.student_name}',
                ip_address=request.META.get('REMOTE_ADDR')
            )
            
    except LeaveRequest.DoesNotExist:
        messages.error(request, 'Leave request not found or access denied')
    
    return redirect('leave_requests')

@login_required
def staff_shoptalk(request):
    if request.user.role != 'staff':
        return redirect('login')
    
    tab = request.GET.get('tab', 'scheduled')
    
    # Handle new session scheduling
    if request.method == 'POST':
        try:
            session = ShopTalkSession.objects.create(
                staff=request.user,
                topic=request.POST.get('topic'),
                scheduled_date=request.POST.get('scheduled_date'),
                description=request.POST.get('description')
            )
            
            # Handle multiple student selections
            student_ids = request.POST.getlist('selected_students[]')
            for student_id in student_ids:
                student = User.objects.get(studentprofile__id=student_id)
                session.assigned_students.add(student)
            
            messages.success(request, 'Session scheduled successfully!')
            return redirect('staff_shoptalk')
        except Exception as e:
            messages.error(request, f'Error scheduling session: {str(e)}')
    
    # Get all sessions created by this staff
    sessions = ShopTalkSession.objects.filter(staff=request.user)
    
    if tab == 'submitted':
        # Get evaluated submissions
        evaluated_submissions = ShopTalkSubmission.objects.filter(
            session__staff=request.user,
            status='evaluated'
        ).select_related(
            'session',
            'student',
            'student__studentprofile'
        )
        context = {
            'evaluated_submissions': evaluated_submissions
        }
    elif tab == 'pending':
        # Get pending submissions
        pending_submissions = ShopTalkSubmission.objects.filter(
            session__staff=request.user,
            status='submitted'
        ).select_related(
            'session',
            'student',
            'student__studentprofile'
        )
        context = {
            'pending_submissions': pending_submissions
        }
    elif tab == 'not_submitted':
        # Get sessions where students haven't submitted
        not_submitted = []
        for session in sessions:
            submitted_students = session.shoptalksubmission_set.values_list('student_id', flat=True)
            not_submitted_students = session.assigned_students.exclude(id__in=submitted_students)
            if not_submitted_students.exists():
                not_submitted.append({
                    'session': session,
                    'students': not_submitted_students
                })
        context = {
            'not_submitted': not_submitted
        }
    else:
        # Scheduled sessions tab
        context = {
            'scheduled_sessions': sessions.prefetch_related(
                'assigned_students',
                'assigned_students__studentprofile'
            )
        }

    # Add common context data
    context.update({
        'tab': tab,
        'students': StudentProfile.objects.filter(user__created_by=request.user),
        'scheduled_count': sessions.count(),
        'submitted_count': ShopTalkSubmission.objects.filter(
            session__staff=request.user,
            status='evaluated'
        ).count(),
        'pending_count': ShopTalkSubmission.objects.filter(
            session__staff=request.user,
            status='submitted'
        ).count()
    })
    
    return render(request, 'staff/shoptalk.html', context)

@login_required
def assign_marks(request, submission_id):
    if request.user.role != 'staff':
        return redirect('login')
        
    if request.method == 'POST':
        try:
            submission = ShopTalkSubmission.objects.get(
                id=submission_id,
                session__staff=request.user
            )
            marks = request.POST.get('marks')
            feedback = request.POST.get('feedback')
            
            if 0 <= int(marks) <= 10:
                submission.marks = marks
                submission.feedback = feedback
                submission.status = 'evaluated'
                submission.save()
                messages.success(request, 'Marks assigned successfully!')
            else:
                messages.error(request, 'Marks must be between 0 and 10')
        except Exception as e:
            messages.error(request, f'Error assigning marks: {str(e)}')
            
    return redirect('staff_shoptalk')

@login_required
def staff_activity_planner(request):
    return render(request, 'staff/activity_planner.html')

@login_required
def staff_activity_hours(request):
    return render(request, 'staff/activity_hours.html')

# Add these new views after the existing staff_shoptalk view

@login_required
def delete_session(request, session_id):
    if request.user.role != 'staff':
        return redirect('login')
        
    try:
        session = ShopTalkSession.objects.get(id=session_id, staff=request.user)
        session.delete()
        messages.success(request, 'Shop Talk session deleted successfully!')
    except ShopTalkSession.DoesNotExist:
        messages.error(request, 'Session not found.')
        
    return redirect('staff_shoptalk')

@login_required
def edit_session(request, session_id):
    if request.user.role != 'staff':
        return redirect('login')
        
    try:
        session = ShopTalkSession.objects.get(id=session_id, staff=request.user)
        
        if request.method == 'POST':
            session.topic = request.POST.get('topic')
            session.scheduled_date = request.POST.get('scheduled_date')
            session.description = request.POST.get('description')
            session.save()
            
            # Update assigned student if changed
            student_id = request.POST.get('selected_students')
            if student_id:
                session.assigned_students.clear()
                student_user = User.objects.get(studentprofile__id=student_id)
                session.assigned_students.add(student_user)
                
            messages.success(request, 'Session updated successfully!')
            return redirect('staff_shoptalk')
            
        context = {
            'session': session,
            'students': StudentProfile.objects.filter(user__created_by=request.user)
        }
        return render(request, 'staff/edit_session.html', context)
        
    except ShopTalkSession.DoesNotExist:
        messages.error(request, 'Session not found.')
        return redirect('staff_shoptalk')

@login_required
def performance_analytics(request):
    return render(request, 'staff/performance_analytics.html')

@login_required
def main_announcements(request):
    if request.user.role != 'staff':
        return redirect('login')
    
    # Get all announcements from all admins
    announcements = Announcement.objects.filter(
        created_by__role='admin'  # Get announcements from any admin
    ).order_by('-created_at')
    
    context = {
        'announcements': announcements
    }
    return render(request, 'staff/main_announcements.html', context)

@login_required
def report_generator(request):
    if request.user.role != 'staff':
        return redirect('login')
    
    context = {}
    report_type = request.GET.get('report_type')
    
    if report_type:
        # Get students under this staff
        students = StudentProfile.objects.filter(
            user__created_by=request.user
        ).select_related('user')
        
        report_data = []
        for student in students:
            # Generate report data based on type
            if report_type == 'attendance':
                report_data.append({
                    'student_name': student.student_name,
                    'total_days': 30,  # Replace with actual calculation
                    'present_days': 25,  # Replace with actual calculation
                    'percentage': 83.33  # Replace with actual calculation
                })
            elif report_type == 'performance':
                report_data.append({
                    'student_name': student.student_name,
                    'assignment_score': 85,  # Replace with actual data
                    'project_score': 90,  # Replace with actual data
                    'overall_grade': 'A'  # Replace with actual calculation
                })
            elif report_type == 'latecoming':
                report_data.append({
                    'student_name': student.student_name,
                    'total_late_days': 5,  # Replace with actual count
                    'average_delay': '15 mins',  # Replace with actual calculation
                    'warning_count': 2  # Replace with actual count
                })
            elif report_type == 'activity':
                report_data.append({
                    'student_name': student.student_name,
                    'activities_completed': 8,  # Replace with actual count
                    'hours_spent': 24,  # Replace with actual calculation
                    'performance_rating': 'Good'  # Replace with actual rating
                })
        
        context.update({
            'report_type': report_type,
            'report_data': report_data
        })
    
    return render(request, 'staff/report_generator.html', context)

@login_required
def activity_log(request):
    if request.user.role != 'staff':
        return redirect('login')
    
    # Get activity logs for the staff
    logs = ActionLog.objects.filter(user=request.user).order_by('-timestamp')  # Changed from created_at to timestamp
    
    # Apply filters
    date_from = request.GET.get('date_from')
    date_to = request.GET.get('date_to')
    action_type = request.GET.get('action_type')
    
    if date_from:
        logs = logs.filter(timestamp__date__gte=date_from)  # Changed from created_at to timestamp
    if date_to:
        logs = logs.filter(timestamp__date__lte=date_to)  # Changed from created_at to timestamp
    if action_type:
        logs = logs.filter(action_type=action_type)
    
    context = {
        'activity_logs': logs
    }
    return render(request, 'staff/activity_log.html', context)


@login_required
def update_staff_profile(request):
    if request.method == 'POST':
        user = request.user
        user.first_name = request.POST.get('first_name')
        user.email = request.POST.get('email')
        user.phone = request.POST.get('phone')
        user.address = request.POST.get('address')
        user.save()
        messages.success(request, 'Profile updated successfully')
    return redirect('staff_profile')
