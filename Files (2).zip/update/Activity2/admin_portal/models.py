from django.conf import settings
from django.db import models
from student.models import StudentProfile

class Announcement(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='created_announcements')

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.title

class StudentProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    student_name = models.CharField(max_length=100)
    roll_number = models.CharField(max_length=20)
    semester = models.IntegerField()
    section = models.CharField(max_length=1)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, 
                                 null=True, related_name='created_students')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.student_name

class LateRecord(models.Model):
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='late_records')
    date = models.DateField()
    time_arrived = models.TimeField()
    minutes_late = models.IntegerField(default=0)
    reason = models.TextField(blank=True, null=True)
    warning_message = models.TextField(blank=True, null=True)  # Add this field
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE,
        null=True,
        default=None
    )

    class Meta:
        ordering = ['-date', '-time_arrived']

    def __str__(self):
        return f"{self.student.student_name} - {self.date}"

class WarningMessage(models.Model):
    late_record = models.ForeignKey(LateRecord, on_delete=models.CASCADE, related_name='warnings')
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    is_read = models.BooleanField(default=False)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Warning for {self.late_record.student.student_name} - {self.created_at.date()}"

class ActionLog(models.Model):
    ACTION_TYPES = [
        ('LOGIN', 'Login'),
        ('LOGOUT', 'Logout'),
        ('CREATE', 'Create'),
        ('UPDATE', 'Update'),
        ('DELETE', 'Delete'),
        ('REPORT', 'Report Generation'),
    ]
    
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    action_type = models.CharField(max_length=20, choices=ACTION_TYPES)
    action_description = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)

    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.user.username} - {self.action_type} - {self.timestamp}"


class LeaveRequest(models.Model):
    LEAVE_TYPES = [
        ('SICK', 'Sick Leave'),
        ('PERSONAL', 'Personal Leave'),
        ('EMERGENCY', 'Emergency Leave'),
        ('OTHER', 'Other')
    ]
    
    STATUS_CHOICES = [
        ('PENDING', 'Pending'),
        ('VERIFIED', 'Verified'),
        ('REJECTED', 'Rejected')
    ]
    
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='leave_requests')
    leave_type = models.CharField(max_length=20, choices=LEAVE_TYPES)
    reason = models.TextField()
    from_date = models.DateField()
    to_date = models.DateField()
    from_time = models.TimeField()
    to_time = models.TimeField()
    total_days = models.IntegerField(default=1)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='PENDING')
    document = models.FileField(upload_to='leave_documents/', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    verified_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,  # Changed from 'CustomUser' to settings.AUTH_USER_MODEL
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='verified_leaves'
    )
    rejection_reason = models.TextField(null=True, blank=True)

    def save(self, *args, **kwargs):
        # Calculate total days including the end date
        if self.from_date and self.to_date:
            delta = self.to_date - self.from_date
            self.total_days = delta.days + 1
        super().save(*args, **kwargs)

    def get_document_name(self):
        if self.document:
            return self.document.name.split('/')[-1]
        return None

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.student.student_name} - {self.leave_type} ({self.from_date} to {self.to_date})"
